const { cusotmer } = require("../db");

const authMiddleWare = async (req, res, next) => {
  try {
    const userName = req.session.userName;
    if (!userName) {
      return res.redirect("/login");
    }
    console.log(`AuthMiddleware ${userName}`)
    const user = await cusotmer.findOne({ userName });
    if (!user) {
      return res.redirect("/login");
    }
    console.log(`user found in session ${user}`);
    next();
  } catch (e) {
    return res.redirect("/login");
  }
};

module.exports = { authMiddleWare };

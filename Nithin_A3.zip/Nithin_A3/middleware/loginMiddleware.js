const loginMiddleWare = async (req, res, next) => {
  try {
    const sessionUserName = req.session.userName;
    if (sessionUserName) {
      return res.redirect("/");
    }
    next();
  } catch (e) {
    return res.redirect("/");
  }
};

module.exports = { loginMiddleWare };

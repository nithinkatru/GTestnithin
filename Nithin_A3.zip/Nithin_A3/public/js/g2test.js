function validateForm() {
  const firstName = $("#firstName").val();
  const lastName = $("#lastName").val();
  const licenseNumber = $("#licenseNumber").val();
  const age = $("#age").val();
  const dob = $("#dob").val();
  const make = $("#make").val();
  const model = $("#model").val();
  const year = $("#year").val();
  const plateNumber = $("#plateNumber").val();

  if (firstName === "") {
    alert("Please enter your first name");
    return false;
  }

  if (lastName === "") {
    alert("Please enter your last name");
    return false;
  }

  if (licenseNumber === "") {
    alert("Please enter your license number");
    return false;
  } else if (!licenseNumber.match(/[A-Za-z0-9]{8}/)) {
    alert(
      "License number should contain alphanumeric characters and be 8 characters long"
    );
    return false;
  }

  if (age === "") {
    alert("Please enter your age");
    return false;
  } else if (isNaN(age)) {
    alert("Age must be a numeric value");
    return false;
  }

  if (dob === "") {
    alert("Please enter your date of birth");
    return false;
  }

  if (make === "") {
    alert("Please enter the car make");
    return false;
  }

  if (model === "") {
    alert("Please enter the car model");
    return false;
  }

  if (year === "") {
    alert("Please enter the car year");
    return false;
  } else if (isNaN(year)) {
    alert("Year must be a numeric value");
    return false;
  }

  if (plateNumber === "") {
    alert("Please enter the plate number");
    return false;
  }

  // Submit the form
  $("#submit_form").submit();

  return true;
}

$(document).ready(() => {
  $("#Submit").on("click", validateForm);

  $("#get_customer_Details").on("click", function () {
    const licenseNumber = $("#licenseNumber").val();
    if (!licenseNumber) {
      alert("Please enter the license number");
      return;
    }

    // Submit the form with license number as part of the action URL
    $("#get_form_details").attr("action", "/user/" + licenseNumber);
    $("#get_form_details").submit();
  });

  $("#Submit_update").on("click", function () {
    $("#submit_form").submit();
  });
});

const express = require("express");
const { authMiddleWare } = require("../middleware/authMiddleware");
const { loginMiddleWare } = require("../middleware/loginMiddleware");
const UserController = require("../controllers/UserController");
const router = express.Router();

router.get("/", authMiddleWare, UserController.homePage);

router.get("/home", authMiddleWare, UserController.homePage);

router.get("/g2test", authMiddleWare, UserController.g2Page);

router.get("/gtest", authMiddleWare, UserController.getCustomerDetails);

router.get("/login", loginMiddleWare, UserController.loginPage);
router.get("/sign_up", loginMiddleWare, UserController.signUpPage);

router.get("/logout", (req, res, next) => UserController.logout);

router.post("/saveUserDATA", authMiddleWare, UserController.savecustomer);
router.get(
  "/user/:licenseNumber",
  authMiddleWare,
  UserController.getCustomerDetails
);
router.post(
  "/update_customer_data",
  authMiddleWare,
  UserController.updateCustomerDetails
);

router.post("/sign_up", loginMiddleWare, UserController.signUp);
router.post("/login", loginMiddleWare, UserController.login);


module.exports = router;
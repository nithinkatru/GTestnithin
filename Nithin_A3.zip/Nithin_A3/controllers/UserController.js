const { cusotmer } = require("../db");
const bcrypt = require("bcrypt");

class UserController {
  static loginPage = (req, res) => {
    res.render("login");
  };

  static signUpPage = (req, res) => {
    res.render("sign_up");
  };

  static g2Page = (req, res) => {
    res.render("g2test");
  };

  static homePage = (req, res) => {
    res.render("home");
  };

  static savecustomer = async (req, res) => {
    try {
      const formDate = req.body;

      const user = await cusotmer.findOneAndUpdate(
        { userName: req.session.userName },
        {
          firstName: formDate.firstName,
          lastName: formDate.lastName,
          licenseNumber: formDate.licenseNumber,
          age: formDate.age,
          car_details: {
            make: formDate.make,
            model: formDate.model,
            year: formDate.year,
            plateNumber: formDate.plateNumber,
          },
        }
      );

      console.log(user);

      res.render("g2test", { user, status: "success" });
    } catch (error) {
      console.log(error);
      res.render("g2test", { status: "failed" });
    }
  };

  static updateCustomerDetails = async (req, res) => {
    try {
      const formDate = req.body;

      await cusotmer.findOneAndUpdate(
        { userName: req.session.userName },
        {
          car_details: {
            make: formDate.make,
            model: formDate.model,
            year: formDate.year,
            plateNumber: formDate.plateNumber,
          },
        }
      );
      res.render("gtest", { status: "updated" });
    } catch (error) {
      console.log(error);
      res.render("gtest", { status: "failed" });
    }
  };

  static getCustomerDetails = async (req, res) => {
    try {
      console.log(req.session.userName);
      const user = await cusotmer.findOne({ userName: req.session.userName });
      console.log(user);
      if (!user || !user.licenseNumber) {
        // redirect it  to the corresponsing ejs
        res.render("gtest", { status: "not_found" });
        return;
      }
      res.render("gtest", { user, status: "found" });
    } catch (error) {
      res.render("gtest", { status: "failed" });
    }
  };

  static signUp = async (req, res) => {
    try {
      const { userName, password, userType } = req.body;

      console.log(userName);
      console.log(password);
      console.log(userType);

      const existingUser = await cusotmer.findOne({ userName });
      if (existingUser) {
        res.render("sign_up", { status: "duplicate" });
        return;
      }

      const user = new cusotmer({
        userName,
        password,
        userType,
      });

      const savedUser = await user.save();
      console.log(savedUser);

      return res.redirect("/login");
    } catch (error) {
      console.log(error);
      res.render("sign_up", { status: "failed" });
    }
  };

  static login = async (req, res) => {
    try {
      const { userName, password } = req.body;

      const user = await cusotmer.findOne({ userName });
      if (user) {
        const same = await bcrypt.compare(password, user.password);
        if (same) {
          req.session.userName = userName;
          res.redirect("/");
          return;
        }
      }
      res.render("login", { status: "invalid" });
    } catch (error) {
      console.log(error);
      res.render("login", { status: "Failed" });
    }
  };

  static logout = async (req, res) => {
    try {
      req.session.userName = null;
      global.loggedIn = null;
      global.userType = null;
      return res.redirect("/login");
    } catch (error) {
      console.log(error);
      res.render("login", { status: "Failed" });
    }
  };
}

module.exports = UserController;
